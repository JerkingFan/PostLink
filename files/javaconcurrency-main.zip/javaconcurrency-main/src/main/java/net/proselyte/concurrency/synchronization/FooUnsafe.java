package net.proselyte.concurrency.synchronization;

public class FooUnsafe {

    public void first() {
        System.out.println("first");
    }

    public void second() {
        System.out.println("second");
    }

    public void third() {
        System.out.println("third");
    }
}
